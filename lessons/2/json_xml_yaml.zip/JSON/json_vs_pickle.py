import json
import os
from github_grabber import json_data


PATH = 'myconfig.json'

if os.path.exists(PATH):
    with open(PATH, 'rb') as f:
        json_data = json.load(f)

pass
# with open(PATH, 'w') as f:
#     json.dump(json_data, f, indent=5)